#ifndef SERVEUR_H
#define SERVEUR_H


class serveur
{
public:
    serveur();
};

#endif // SERVEUR_H
