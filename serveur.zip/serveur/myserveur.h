#ifndef MYSERVEUR_H
#define MYSERVEUR_H

#include "ui_widget.h"
#include <QTcpServer>
#include <QTcpSocket>
#include <QNetworkInterface>
#include <QMessageBox>

class MyServeur : public QDialog
{
    Q_OBJECT

public:
    explicit MyServeur(Ui::Widget* u, QWidget *parent=nullptr);
    void serveurOn();
    ~MyServeur();

private:
    Ui::Widget *ui;
    QTcpServer *tcpServeur;
    QList<QTcpSocket*> tcpClient;
    QTcpSocket *currentClient;

    QPushButton *btn_serveur;
    QLabel *lb_ip;
    QLabel *lb_port;
    QTextEdit *txt_recu;
    QTextEdit *txt_envoie;
    QPushButton *btn_envoie;

private slots:
    void newConnectionSlot();
    void disconnectionSlot();
    void readData();
    void on_btn_serveur_clicked();
    void on_btn_envoie_clicked();


};


#endif // MYSERVEUR_H













