#include "serveur.h"
#include "ui_widget.h"
#include "ui_serveur.h"

serveur::serveur()
{

}
