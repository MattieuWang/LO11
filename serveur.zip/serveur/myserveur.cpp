#include "myserveur.h"

MyServeur::MyServeur(Ui::Widget* u, QWidget *parent)
    : QDialog(parent)
    , ui(u)
    , btn_envoie(ui->btn_envoie)
    , btn_serveur(ui->btn_serveur)
    , txt_envoie(ui->txt_envoie)
    , txt_recu(ui->txt_recu)
    , lb_ip(ui->lb_ip)
    , lb_port(ui->lb_port)
{
    lb_ip->setText("0.0.0.0");
    lb_port->setText("00000");
}

MyServeur::~MyServeur()
{
    delete ui;
}

void MyServeur::serveurOn() // initialisation de tcp serveur
{
    tcpServeur = new QTcpServer(this);
    QString ipAddress = "";
    QList<QHostAddress> ipAddressList = QNetworkInterface::allAddresses();

    for (int i = 0; i < ipAddressList.size(); ++i) {
        if(ipAddressList.at(i) != QHostAddress::LocalHost &&
                ipAddressList.at(i).toIPv4Address())
        {
            ipAddress = ipAddressList.at(i).toString();
            printf("host: %s\n",ipAddress.toStdString().data());
            break;
        }
    }
    printf("port: %d",tcpServeur->serverPort());
    lb_ip->setText(ipAddress);
    lb_port->setText((QString)tcpServeur->serverPort());
    connect(tcpServeur,SIGNAL(newConnection()),this, SLOT(newConnectionSlot()));
}

void MyServeur::newConnectionSlot()
{
    currentClient = tcpServeur->nextPendingConnection();
    tcpClient.append(currentClient);

    connect(currentClient,SIGNAL(readyRead()),this,SLOT(readData()));
    connect(currentClient,SIGNAL(disconnected()),this,SLOT(disconnectionSlot()));

}

void MyServeur::readData()
{
    for (int i = 0; i < tcpClient.length(); ++i) {
        QByteArray buffer = tcpClient[i]->readAll();
        if(buffer.isEmpty())    continue;
        static QString IP_PORT;
        IP_PORT = tr("[%1 : %2]").arg(tcpClient[i]->peerAddress().toString().split("::ffff:")[1]\
                .arg(tcpClient[i]->peerPort()));
        txt_recu->append(buffer);
    }
}

void MyServeur::disconnectionSlot()
{
    for (int i = 0; i < tcpClient.length(); ++i) {
        if(tcpClient[i]->state() == QAbstractSocket::UnconnectedState){
            tcpClient[i]->destroyed();
            tcpClient.removeAt(i);
        }
    }
}



void MyServeur::on_btn_serveur_clicked()
{
    if(btn_serveur->text().contains("on",Qt::CaseInsensitive))
    {
        serveurOn();
        btn_serveur->setText("Serveur Off");
    }
    else {
        lb_ip->setText("0.0.0.0");
        lb_port->setText("00000");
        btn_serveur->setText("Serveur On");
    }
}

void MyServeur::on_btn_envoie_clicked()
{
    QString data = txt_envoie->toPlainText();
    if(data == "") return;

    for (int i = 0; i < tcpClient.length(); ++i) {
        if(tcpClient[i]->peerAddress().toString().split("::ffff:")[1]== lb_ip->text()\
                && tcpClient[i]->peerPort()==lb_port->text())
        {
            tcpClient[i]->write(data.toLatin1());
            txt_envoie->setText("");
            return;
        }
    }
}












