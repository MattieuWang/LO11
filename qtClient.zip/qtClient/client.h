#ifndef CLIENT_H
#define CLIENT_H

#include <QtWidgets>
#include <QTcpServer>
#include <QTcpSocket>
#include <ui_widget.h>

class Client : public QDialog
{
    Q_OBJECT

public:
    explicit Client(Ui::Widget* ui,QWidget *parent = nullptr);
    void connectToServer();

private slots:

    void readData();
    void displayError(QAbstractSocket::SocketError socketError);
    void on_btn_envoie_clicked();
    void on_btn_connecter_clicked();


private:

    Ui::Widget * main_ui;

    QLineEdit *hostLineEdit = nullptr;
    QLineEdit *portLineEdit = nullptr;
    QLabel *statusLabel = nullptr;
    QPushButton *btn_connecter = nullptr;
    QPushButton *btn_envoie = nullptr;
    QTextEdit *txt_recu;
    QTextEdit *txt_envoie;

    QTcpSocket *tcpSocket = nullptr;
    QDataStream in;
    QString currentFortune;

};

#endif // CLIENT_H
