#ifndef CLIENT_H
#define CLIENT_H

#include <QtWidgets>
#include <QTcpServer>
#include <QTcpSocket>
#include <ui_widget.h>

class Client : public QDialog
{
    Q_OBJECT

public:
    explicit Client(Ui::Widget* ui,QWidget *parent = nullptr);
    void requestNewFortune();

private slots:

    void readFortune();
    void displayError(QAbstractSocket::SocketError socketError);
    void enableGetFortuneButton();

private:

    Ui::Widget * main_ui;

    QLineEdit *hostLineEdit = nullptr;
    QLineEdit *portLineEdit = nullptr;
    QLabel *statusLabel = nullptr;
    QPushButton *getFortuneButton = nullptr;

    QTcpSocket *tcpSocket = nullptr;
    QDataStream in;
    QString currentFortune;

};

#endif // CLIENT_H
