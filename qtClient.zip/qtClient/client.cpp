#include "client.h"
#include <QTime>
#include <iostream>
#include <QAbstractSocket>
using namespace std;

Client::Client(Ui::Widget* ui,QWidget *parent)
    : QDialog(parent)
    , main_ui(ui)
    , hostLineEdit(main_ui->hostLineEdit)
    , portLineEdit(main_ui->portLineEdit)
    , getFortuneButton(main_ui->btn_getFortune)
    , tcpSocket(new QTcpSocket(this))
{

    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);
    in.setDevice(tcpSocket);
    in.setVersion(QDataStream::Qt_5_10);

//    getFortuneButton = main_ui->btn_getFortune;

    //connect(tcpSocket,&QIODevice::readyRead,this,&Client::readFortune);
    connect(tcpSocket,SIGNAL(readyRead()),this,SLOT(readFortune()));
    connect(tcpSocket,SIGNAL(error(QAbstractSocket::SocketError)),this
            ,SLOT(displayError(QAbstractSocket::SocketError)));

}

void Client::requestNewFortune()
{
    getFortuneButton->setEnabled(false);
    tcpSocket->abort();
    tcpSocket->connectToHost(hostLineEdit->text(),
                             portLineEdit->text().toInt());
    cout<<"host: "<<hostLineEdit->text().data()<<endl<<"port: "<<portLineEdit->text().data()<<endl;

}

void Client::displayError(QAbstractSocket::SocketError socketError)
{
    switch (socketError) {
    case QAbstractSocket::RemoteHostClosedError:
        break;
    case QAbstractSocket::HostNotFoundError:
        cout<<"host not found"<<endl;
        break;
    case QAbstractSocket::ConnectionRefusedError:
        cout<<"Connection refused"<<endl;
        break;
    default:
        cout<<tcpSocket->errorString().data()<<endl;
        break;
    }

    getFortuneButton->setEnabled(true);
}

void Client::readFortune()
{
    in.startTransaction();
    QString nextFortune;
    in >> nextFortune;
    if(!in.commitTransaction())
    {
        cout<<"no message"<<endl;
        return;
    }
    if(nextFortune == currentFortune)
    {
        QTimer::singleShot(0,this,&Client::requestNewFortune);
        return;
    }
    currentFortune = nextFortune;
    statusLabel->setText(currentFortune);
    getFortuneButton->setEnabled(true);
}


void Client::enableGetFortuneButton(){getFortuneButton->setEnabled(true);}


















