#include "client.h"
#include <QTime>
#include <iostream>
#include <QAbstractSocket>
using namespace std;

Client::Client(Ui::Widget* ui,QWidget *parent)
    : QDialog(parent)
    , main_ui(ui)
    , hostLineEdit(main_ui->hostLineEdit)
    , portLineEdit(main_ui->portLineEdit)
    , btn_connecter(main_ui->btn_connecter)
    , tcpSocket(new QTcpSocket(this))
{

    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);
    in.setDevice(tcpSocket);
    in.setVersion(QDataStream::Qt_5_10);

//    getFortuneButton = main_ui->btn_getFortune;

    //connect(tcpSocket,&QIODevice::readyRead,this,&Client::readFortune);
    connect(tcpSocket,SIGNAL(readyRead()),this,SLOT(readFortune()));
    connect(tcpSocket,SIGNAL(error(QAbstractSocket::SocketError)),this
            ,SLOT(displayError(QAbstractSocket::SocketError)));

}

void Client::connectToServer()
{
    btn_connecter->setEnabled(false);
    tcpSocket->abort();
    tcpSocket->connectToHost(hostLineEdit->text(),
                             portLineEdit->text().toInt());
    printf("host: %s\nport: %s\n",hostLineEdit->text().toStdString().data(),portLineEdit->text().toStdString().data());

}

void Client::displayError(QAbstractSocket::SocketError socketError)
{
    switch (socketError) {
    case QAbstractSocket::RemoteHostClosedError:
        break;
    case QAbstractSocket::HostNotFoundError:
        cout<<"host not found"<<endl;
        break;
    case QAbstractSocket::ConnectionRefusedError:
        cout<<"Connection refused"<<endl;
        break;
    default:
        cout<<tcpSocket->errorString().data()<<endl;
        break;
    }

    btn_connecter->setEnabled(true);
}

void Client::readData()
{
    in.startTransaction();
    QString nextFortune;
    in >> nextFortune;
    if(!in.commitTransaction())
    {
        cout<<"no message"<<endl;
        return;
    }
    if(nextFortune == currentFortune)
    {
        QTimer::singleShot(0,this,&Client::requestNewFortune);
        return;
    }
    currentFortune = nextFortune;
    statusLabel->setText(currentFortune);
    btn_connecter->setEnabled(true);
}



void Client::on_btn_envoie_clicked()
{
    QString data = txt_envoie->toPlainText();
    if(data == "") return;

    for (int i = 0; i < tcpClient.length(); ++i) {
        if(tcpClient[i]->peerAddress().toString().split("::ffff:")[1]== lb_ip->text()\
                && tcpClient[i]->peerPort()==lb_port->text())
        {
            tcpClient[i]->write(data.toLatin1());
            txt_envoie->setText("");
            return;
        }
    }
}


void Client::on_btn_connecter_clicked()
{
    connectToServer();
}















