#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

Ui::Widget* Widget::getUI(){return ui;}

void Widget::setClient(Client *c){client = c;}

void Widget::on_btn_getFortune_clicked()
{
    client->requestNewFortune();
}
